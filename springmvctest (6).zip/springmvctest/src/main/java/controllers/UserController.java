package controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.scs.dao.Registration;

@Controller
public class UserController {
	@RequestMapping("/dashboard")
    public ModelAndView home(HttpServletRequest request)
    {
		 HttpSession session = request.getSession();
		 if(session.getAttribute("uid")==null)
		 {
			 return new ModelAndView("redirect:home.do");
		 }
		 else
		 {
		Configuration cfg = new Configuration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory sf = cfg.buildSessionFactory();

		Session sess = sf.openSession();
      
        
		Query q = sess.createQuery("from Registration r where r.username=:a");
		q.setString("a",session.getAttribute("uid").toString());
		List lst = q.list();
		
    	return new ModelAndView("userdashboard","key",lst);
		 }
    }
	@RequestMapping("/logout")
	public ModelAndView logout(HttpServletRequest request)
	{
		HttpSession session = request.getSession();
		session.removeAttribute("uid");
		return new ModelAndView("redirect:home.do");
	}
	@RequestMapping("/EditUser")
    public ModelAndView edituser(HttpServletRequest request)
    {
		Configuration cfg = new Configuration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory sf = cfg.buildSessionFactory();

		Session sess = sf.openSession();

		Object q = sess.load(Registration.class,request.getParameter("uid"));
		
    	return new ModelAndView("edituser","key",q);
    }
	@RequestMapping("/updateuser")
    public ModelAndView updateuser(HttpServletRequest request)
    {
		Configuration cfg = new Configuration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory sf = cfg.buildSessionFactory();

		Session sess = sf.openSession();

		Registration o =(Registration)sess.load(Registration.class,request.getParameter("txtname"));
		o.setPassword(request.getParameter("txtpass"));
		o.setEmail(request.getParameter("txtemail"));
		o.setMobileno(request.getParameter("txtmobile"));
		Transaction tx = sess.beginTransaction();
		sess.update(o);
		tx.commit();
		sess.close();
    	return new ModelAndView("redirect:dashboard.do");
    }
}
