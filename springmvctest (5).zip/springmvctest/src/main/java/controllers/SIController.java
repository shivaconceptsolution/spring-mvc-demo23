package controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.scs.beans.SI;

@Controller
public class SIController {
@RequestMapping("siload")
public ModelAndView siLoad()
{
	 return new ModelAndView("siview", "command", new SI());
}
@RequestMapping("silogic")
public ModelAndView siLogic(@ModelAttribute("springmvctest")SI s)
{
	 float result = (s.getP()*s.getR()*s.getT())/100;
	 ModelAndView obj= new ModelAndView("siview", "command", new SI());
	 obj.addObject("key",result);
	 return obj;
}

}
