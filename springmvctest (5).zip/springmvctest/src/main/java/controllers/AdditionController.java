package controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AdditionController {
   @RequestMapping("add")
   public ModelAndView additionView()
   {
	   return new ModelAndView("addition");
   }
   @RequestMapping("addlogic")
   public ModelAndView additionLogic(HttpServletRequest request)
   {
	   int a = Integer.parseInt(request.getParameter("txtnum1"));
       int b = Integer.parseInt(request.getParameter("txtnum2"));
       int c = a+b;
	   return new ModelAndView("additionresult","key","result is "+c);
   }
}
