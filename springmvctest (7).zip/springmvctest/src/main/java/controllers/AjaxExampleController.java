package controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.scs.dao.Registration;

@Controller
public class AjaxExampleController {
@RequestMapping("ajaxload")
public ModelAndView ajaxLoad()
{
	return new ModelAndView("ajaxload");
}
@RequestMapping("ajaxprocess")
public ModelAndView ajaxProcess(HttpServletRequest req)
{
	String s = req.getParameter("q");
	Configuration cfg = new Configuration();
	cfg.configure("hibernate.cfg.xml");
	SessionFactory sf = cfg.buildSessionFactory();
	Session sess = sf.openSession();
	Criteria q = sess.createCriteria(Registration.class);
	 Criterion rt = Restrictions.like("username",s,MatchMode.START); 
	 q.add(rt);
	 List lst = q.list();
	 return new ModelAndView("ajaxprocess","key",lst);
}
}
